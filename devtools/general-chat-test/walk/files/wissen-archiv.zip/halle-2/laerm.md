# Lärmschutz Halle 2

In Halle 2 gilt ab 85 dB Gehörschutzpflicht. Prüfmarke ZIP-HALLE2.
