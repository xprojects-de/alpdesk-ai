# Brandschutz Halle 1

Der Sammelplatz der Halle 1 ist Tor C. Prüfmarke ZIP-HALLE1.
